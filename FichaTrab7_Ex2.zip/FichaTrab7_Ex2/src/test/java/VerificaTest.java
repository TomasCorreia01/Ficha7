import static org.junit.jupiter.api.Assertions.*;

import org.example.Verifica;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class VerificaTest {
    @ParameterizedTest
    @ValueSource(ints = {3, 23, 311, 487, 653, 947})
public void testIsPrimeWithPrimes(int number) {
    assertTrue(Verifica.isPrime(number));
}

    @ParameterizedTest
    @ValueSource(ints = {32, 64, 2, 20, 30, 26})
    public void testIsEvenWithEvens(int number) {
        assertTrue(Verifica.isEven(number));
    }

    @ParameterizedTest
    @ValueSource(ints = {23, 46, 115, 184, 207, 230})
    public void testIsMultipleOf23(int number) {
        assertTrue(Verifica.isMultiple(number, 23));
    }

    @ParameterizedTest
    @ValueSource(ints = {40, 103, 834})
    public void testIsNotPrimeAndEvenAndNotMultipleOf23(int number) {
        assertFalse(Verifica.isPrime(number));
        assertFalse(Verifica.isEven(number));
        assertFalse(Verifica.isMultiple(number, 23));
    }
}

